int LLAMA_BUILD_NUMBER = 1663;
char const *LLAMA_COMMIT = "799fc22";
char const *LLAMA_COMPILER = "cc (GCC) 13.2.0";
char const *LLAMA_BUILD_TARGET = "x86_64-w64-mingw32";
